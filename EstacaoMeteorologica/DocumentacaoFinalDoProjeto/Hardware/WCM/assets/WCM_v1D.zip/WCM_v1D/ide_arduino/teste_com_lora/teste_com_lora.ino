#include <SPI.h>
#include <LoRa.h>

// --------------------------
// Pinos conforme seu esquema
// --------------------------
#define LORA_SS    2   // NSS
#define LORA_RST   4   // RESET
#define LORA_DIO0  3   // DIO0

// Frequência LoRa no Brasil
#define LORA_BAND  915E6

void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println("===== Teste RFM95W + XIAO ESP32-C3 =====");
  Serial.println("Iniciando LoRa...");

  // Define os pinos do módulo
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);

  // Inicializa o rádio LoRa
  if (!LoRa.begin(LORA_BAND)) {
    Serial.println("Falha ao iniciar LoRa! Verifique as conexões.");
    while (1);
  }

  Serial.println("LoRa inicializado com sucesso!");
  Serial.println("---------------------------------------");
  Serial.println("Enviando pacotes a cada 5 segundos...");
}

void loop() {
  Serial.print("Enviando pacote: ");
  Serial.println(millis());

  LoRa.beginPacket();
  LoRa.print("Pacote de teste - tempo=");
  LoRa.print(millis());
  LoRa.endPacket();  // Envia o pacote

  delay(5000);
}
